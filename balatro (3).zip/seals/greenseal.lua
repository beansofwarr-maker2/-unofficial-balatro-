
SMODS.Seal {
    key = 'greenseal',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xmultseal = 1
        }
    },
    badge_colour = HEX('32CD32'),
    loc_txt = {
        name = 'Green seal',
        label = 'Green seal',
        text = {
            [1] = '{X:red,C:white}+1.5X{} Mult for every time this card is either',
            [2] = 'played or discarded',
            [3] = '{C:inactive}(currently{} {X:red,C:white}#1#X{} {C:inactive}mult){}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "gong", per = 1.2, vol = 0.4 },
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.seal.extra.xmultseal}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            card.ability.extra.xmultseal = (card.ability.extra.xmultseal) + 1
        end
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = card.ability.seal.extra.xmultseal
            }
        end
        if context.discard and context.other_card == card then
            return {
                func = function()
                    card.ability.extra.xmultseal = (card.ability.extra.xmultseal) + 1
                    return true
                end
            }
        end
    end
}