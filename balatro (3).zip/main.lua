SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/reddragon.lua"))()
    assert(SMODS.load_file("jokers/bloodmoon.lua"))()
    assert(SMODS.load_file("jokers/scrambledcube.lua"))()
    assert(SMODS.load_file("jokers/unicornhorn.lua"))()
    assert(SMODS.load_file("jokers/oldscratch.lua"))()
    assert(SMODS.load_file("jokers/skomorokh.lua"))()
    assert(SMODS.load_file("jokers/smoothmarble.lua"))()
    assert(SMODS.load_file("jokers/wedding.lua"))()
    assert(SMODS.load_file("jokers/stainedglass.lua"))()
    assert(SMODS.load_file("jokers/uptheranks.lua"))()
    assert(SMODS.load_file("jokers/sockandbuskinbut3d.lua"))()
end
-- load the seals
if true then
    assert(SMODS.load_file("seals/greenseal.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/gradient_deck.lua"))()
end


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
SMODS.ObjectType({
    key = "balatro_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "balatro_balatro_jokers",
    cards = {
        ["j_balatro_reddragon"] = true,
        ["j_balatro_bloodmoon"] = true,
        ["j_balatro_scrambledcube"] = true,
        ["j_balatro_unicornhorn"] = true,
        ["j_balatro_oldscratch"] = true,
        ["j_balatro_skomorokh"] = true,
        ["j_balatro_smoothmarble"] = true,
        ["j_balatro_wedding"] = true,
        ["j_balatro_stainedglass"] = true,
        ["j_balatro_uptheranks"] = true,
        ["j_balatro_sockandbuskinbut3d"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end