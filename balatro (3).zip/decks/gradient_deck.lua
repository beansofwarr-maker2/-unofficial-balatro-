
SMODS.Back {
    key = 'gradient_deck',
    pos = { x = 0, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Gradient Deck',
        text = {
            [1] = '{C:blue}+1 hands{} {C:attention}and{} {C:red}+2 discards{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 2
    end
}