
SMODS.Joker{ --Wedding
    key = "wedding",
    config = {
        extra = {
            wedding = 0,
            dollars0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Wedding',
        ['text'] = {
            [1] = 'if played hand contains',
            [2] = 'both a scoring',
            [3] = 'King and Queen,',
            [4] = 'earn {C:money}4${}',
            [5] = '{C:green}(credits to TheOfficialBeacon){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.wedding}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 13 then
                card.ability.extra.wedding = (card.ability.extra.wedding) + 1
            elseif context.other_card:get_id() == 13 then
                card.ability.extra.wedding = (card.ability.extra.wedding) + 1
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if to_big((card.ability.extra.wedding or 0)) == to_big(2) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 4
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(4), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.wedding = 0
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
    end
}