
SMODS.Joker{ --Unicorn Horn
    key = "unicornhorn",
    config = {
        extra = {
            yes = 0
        }
    },
    loc_txt = {
        ['name'] = 'Unicorn Horn',
        ['text'] = {
            [1] = '{C:inactive}[LIMITATIONS]{}, This joker gains {C:red}+3 mult{}',
            [2] = 'whenever you {C:inactive}[use]{} a {C:tarot}tarot{} {C:planet}planet{} or',
            [3] = '{C:spectral}spectral{} card',
            [4] = '{C:green}(credits to MyPhoneIsDeadBro){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.yes}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            return {
                func = function()
                    card.ability.extra.yes = (card.ability.extra.yes) + 3
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.yes
            }
        end
    end
}