
SMODS.Joker{ --sock and buskin but 3D
    key = "sockandbuskinbut3d",
    config = {
        extra = {
            repetitions0 = 2,
            repetitions = 2,
            repetitions2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'sock and buskin but 3D',
        ['text'] = {
            [1] = '{C:attention}retrigger all face cards 2x{}',
            [2] = '{C:green}(Made by me!){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:get_id() == 11 then
                return {
                    repetitions = 2,
                    message = localize('k_again_ex')
                }
            elseif context.other_card:get_id() == 12 then
                return {
                    repetitions = 2,
                    message = localize('k_again_ex')
                }
            elseif context.other_card:get_id() == 13 then
                return {
                    repetitions = 2,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}