
SMODS.Joker{ --Up The Ranks
    key = "uptheranks",
    config = {
        extra = {
            sdsd = 0,
            chips0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Up The Ranks',
        ['text'] = {
            [1] = 'add {C:inactive}[chips?]{} of first played',
            [2] = 'card by {C:blue}10{} {C:inactive}[so ace would be 20',
            [3] = 'if it was first only for that occasion]{}',
            [4] = '{C:green}(Credits to DerCriado/Zankokunaten){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.sdsd}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if to_big((card.ability.extra.sdsd or 0)) == to_big(1) then
                return {
                    chips = 10
                }
            else
                card.ability.extra.sdsd = (card.ability.extra.sdsd) + 1
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.sdsd = 0
                    return true
                end
            }
        end
    end
}