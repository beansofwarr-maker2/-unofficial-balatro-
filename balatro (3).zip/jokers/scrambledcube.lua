
SMODS.Joker{ --Scrambled Cube
    key = "scrambledcube",
    config = {
        extra = {
            kenos = 0
        }
    },
    loc_txt = {
        ['name'] = 'Scrambled Cube',
        ['text'] = {
            [1] = 'This joker gains {C:red}1+ mult{} for each',
            [2] = 'different suit in played hand.',
            [3] = 'Resets when played hand contains',
            [4] = 'only one suit. {C:inactive}(currently +#1# mult){}',
            [5] = '{C:green}(credits to MyPhoneIsDeadBro){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.kenos}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Spades") then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                card.ability.extra.kenos = (card.ability.extra.kenos) + 1
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Hearts") then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                card.ability.extra.kenos = (card.ability.extra.kenos) + 1
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Diamonds") then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                card.ability.extra.kenos = (card.ability.extra.kenos) + 1
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Clubs") then
                        count = count + 1
                    end
                end
                return count >= 1
            end)() then
                card.ability.extra.kenos = (card.ability.extra.kenos) + 1
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Spades") then
                        count = count + 1
                    end
                end
                return count == #context.full_hand
            end)() then
                card.ability.extra.kenos = 0
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Hearts") then
                        count = count + 1
                    end
                end
                return count == #context.full_hand
            end)() then
                card.ability.extra.kenos = 0
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Diamonds") then
                        count = count + 1
                    end
                end
                return count == #context.full_hand
            end)() then
                card.ability.extra.kenos = 0
            elseif (function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:is_suit("Clubs") then
                        count = count + 1
                    end
                end
                return count == #context.full_hand
            end)() then
                card.ability.extra.kenos = 0
            else
                return {
                    mult = card.ability.extra.kenos
                }
            end
        end
    end
}