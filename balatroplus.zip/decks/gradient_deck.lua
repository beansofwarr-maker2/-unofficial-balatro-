
SMODS.Back {
    key = 'gradient_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 3
        },
    },
    loc_txt = {
        name = 'Gradient Deck',
        text = {
            [1] = '{C:blue}+2 hands{} {C:attention}BUT{} {C:hearts}3x blind size{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 3
                return true
            end
        }))
    end
}