
SMODS.Consumable {
    key = 'exorcism',
    set = 'Spectral',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = 'Exorcism',
        text = {
            [1] = 'Removes {C:attention}all stickers{} from',
            [2] = 'a random joker',
            [3] = '{C:inactive}(usually for different stakes)',
            [4] = '{}{C:green}(credits to aradial){}'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        local index = math.random(1, #G.jokers.cards)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                used_card:juice_up(0.3, 0.5)
                return true
            end
        }))
        local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.15,
            func = function()
                
                G.jokers.cards[index]:flip()
                play_sound('card1', percent)
                G.jokers.cards[index]:juice_up(0.3, 0.3)
                return true
            end
        }))
        delay(0.2)
        
        
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                
                G.jokers.cards[index].ability.eternal = false
                G.jokers.cards[index].ability.rental = false
                G.jokers.cards[index].ability.perishable = false
                return true
            end
        }))
        local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.15,
            func = function()
                G.jokers.cards[index]:flip()
                play_sound('tarot2', percent, 0.6)
                G.jokers.cards[index]:juice_up(0.3, 0.3)
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.jokers:unhighlight_all()
                return true
            end
        }))
        delay(0.5)
    end,
    can_use = function(self, card)
        return true
    end
}