
SMODS.Booster {
    key = 'balatro_pack',
    loc_txt = {
        name = "Balatro+ pack",
        text = {
            [1] = 'Choose {C:attention}1{} from {C:attention}4{} cards'
        },
        group_name = "balatro_boosters"
    },
    config = { extra = 4, choose = 1 },
    weight = 0.75,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true
        }
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'mega_balatro_pack',
        loc_txt = {
            name = "MEGA balatro+ pack",
            text = {
                [1] = 'Choose {C:attention}2{} out of {C:attention}6{} cards'
            },
            group_name = "balatro_boosters"
        },
        config = { extra = 6, choose = 2 },
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true
            }
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        