
SMODS.Joker{ --Red dragon
    key = "reddragon",
    config = {
        extra = {
            boss = 200,
            actual_mult = 1,
            rdgggssdsdf = 200,
            bossa = 0
        }
    },
    loc_txt = {
        ['name'] = 'Red dragon',
        ['text'] = {
            [1] = 'This joker gains {X:red,C:white}+0.2X{} Mult whenever your',
            [2] = 'score catches fire',
            [3] = '{C:inactive}(currently #2#X mult){}',
            [4] = '{C:green}(credits to MyPhoneIsDeadBro){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.boss, card.ability.extra.actual_mult, card.ability.extra.rdgggssdsdf, card.ability.extra.bossa}}
    end,
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            if to_big(G.GAME.chips / G.GAME.blind.chips) > to_big(NaN) then
                return {
                    func = function()
                        card.ability.extra.actual_mult = (card.ability.extra.actual_mult) + 0.2
                        return true
                    end
                }
            end
        end
        if context.setting_blind  then
            return {
                func = function()
                    card.ability.extra.bossa = (card.ability.extra.bossa) * 1.5
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.actual_mult
            }
        end
    end
}