
SMODS.Joker{ --Album Cover
    key = "albumcover",
    config = {
        extra = {
            booster_slots0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Album Cover',
        ['text'] = {
            [1] = 'All boosters have an {C:attention}Extra{} slot',
            [2] = '{C:green}(Credits to Omicra98){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Booster Slots", colour = G.C.BLUE})
                    
                    SMODS.change_booster_limit(1)
                    return true
                end
            }
        end
    end
}