
SMODS.Joker{ --Observational Joker
    key = "observationaljoker",
    config = {
        extra = {
            odds = 4,
            xmult0 = 3,
            mult0 = 20
        }
    },
    loc_txt = {
        ['name'] = 'Observational Joker',
        ['text'] = {
            [1] = '{C:red}+20{} Mult {C:attention}AND{} {C:green}1 in 20 chance{}',
            [2] = 'to give {X:red,C:white}X3{} Mult',
            [3] = '{C:green}(credits to No_Night_6600 for design){}',
            [4] = '{C:green}(credits to Picklitto for name){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_balatro_observationaljoker') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_0acedc45', 1, card.ability.extra.odds, 'j_balatro_observationaljoker', false) then
                    SMODS.calculate_effect({Xmult = 3}, card)
                end
            else
                return {
                    mult = 20
                }
            end
        end
    end
}