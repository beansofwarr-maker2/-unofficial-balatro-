
SMODS.Joker{ --NUCLEAR BOMB
    key = "nuclearbomb",
    config = {
        extra = {
            multy = 1
        }
    },
    loc_txt = {
        ['name'] = 'NUCLEAR BOMB',
        ['text'] = {
            [1] = 'this joker gains {X:red,C:white}+X0.05{} every card played',
            [2] = '{C:green}(Credits to ghost-church){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multy}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            card.ability.extra.multy = (card.ability.extra.multy) + 0.05
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.multy
            }
        end
    end
}