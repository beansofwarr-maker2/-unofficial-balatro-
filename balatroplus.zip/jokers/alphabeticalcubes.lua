
SMODS.Joker{ --alphabetical cubes
    key = "alphabeticalcubes",
    config = {
        extra = {
            dfef = 1
        }
    },
    loc_txt = {
        ['name'] = 'alphabetical cubes',
        ['text'] = {
            [1] = 'every single {C:attention}ante{} makes',
            [2] = 'this joker gain {X:red,C:white}+X1{} Mult',
            [3] = '{C:inactive}(currently #1#X mult){}',
            [4] = '{C:green}(credits to No_Night_6600 ONLY FOR DESIGN){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.dfef}}
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                func = function()
                    card.ability.extra.dfef = (card.ability.extra.dfef) + 1
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.dfef
            }
        end
    end
}