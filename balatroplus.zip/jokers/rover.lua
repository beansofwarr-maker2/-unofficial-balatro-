
SMODS.Joker{ --Rover
    key = "rover",
    config = {
        extra = {
            mars = 0
        }
    },
    loc_txt = {
        ['name'] = 'Rover',
        ['text'] = {
            [1] = 'Gain {C:red}1+ mult{} per {C:attention}Stone{} card played',
            [2] = '{C:inactive}(currently #1# mult){}',
            [3] = '{C:green}(credits to Omicra98){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.mars}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                card.ability.extra.mars = (card.ability.extra.mars) + 1
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.mars
            }
        end
    end
}