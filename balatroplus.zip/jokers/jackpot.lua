
SMODS.Joker{ --Jackpot
    key = "jackpot",
    config = {
        extra = {
            odds = 2,
            dollars0 = 3,
            odds2 = 100,
            dollars = 350
        }
    },
    loc_txt = {
        ['name'] = 'Jackpot',
        ['text'] = {
            [1] = '{C:green}1 in 2 chance{} for each scored',
            [2] = '{C:attention}7{} to give you {C:money}3${},',
            [3] = '{C:green}1 in 100 chance{} to win {C:money}350${} instead',
            [4] = 'but {C:hearts}SELF DESTRUCTS{}',
            [5] = '{C:green}(credits to Lord of the Dawn/AYYLMAO2281337){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_balatro_jackpot')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_balatro_jackpot')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 7 then
                if SMODS.pseudorandom_probability(card, 'group_0_75f151ab', 1, card.ability.extra.odds, 'j_balatro_jackpot', false) then
                    SMODS.calculate_effect({
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 3
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(3), colour = G.C.MONEY})
                            return true
                        end}, card)
                    end
                elseif context.other_card:get_id() == 7 then
                    if SMODS.pseudorandom_probability(card, 'group_0_9760282e', 1, card.ability.extra.odds2, 'j_balatro_jackpot', false) then
                        local target_joker = card
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                play_sound("balatro_JACKPOTTT")
                                
                                return true
                            end,
                        }))
                        SMODS.calculate_effect({
                            func = function()
                                
                                local current_dollars = G.GAME.dollars
                                local target_dollars = G.GAME.dollars + 350
                                local dollar_value = target_dollars - current_dollars
                                ease_dollars(dollar_value)
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(350), colour = G.C.MONEY})
                                return true
                            end}, card)
                        end
                    end
                end
            end
        }