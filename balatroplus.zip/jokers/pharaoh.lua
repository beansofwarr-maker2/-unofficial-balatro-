
SMODS.Joker{ --Pharaoh
    key = "pharaoh",
    config = {
        extra = {
            sdfsdfasdf = 5,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Pharaoh',
        ['text'] = {
            [1] = '{X:red,C:white}3X{} Mult if money held is',
            [2] = '{C:attention}greater or equal{} to {C:money}$#1#{}',
            [3] = 'increases by {C:attention}$5{} every ante',
            [4] = '{C:green}(credits to Omicra98){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.sdfsdfasdf}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.sdfsdfasdf = (card.ability.extra.sdfsdfasdf) + 5
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.dollars) >= to_big(card.ability.extra.sdfsdfasdf) then
                return {
                    Xmult = 3
                }
            end
        end
    end
}