
SMODS.Joker{ --Stañczyk
    key = "staczyk",
    config = {
        extra = {
            easier_time = 0,
            hand_size0 = 2,
            hand_size = 2,
            hand_size2 = 7,
            hand_size3 = 7,
            hand_size4 = 7,
            hand_size5 = 7
        }
    },
    loc_txt = {
        ['name'] = 'Stañczyk',
        ['text'] = {
            [1] = 'After play or discard,',
            [2] = 'draw {C:attention}+2{} additional cards',
            [3] = '{C:inactive}(but resets to 7 every 2nd ante){}',
            [4] = '{C:green}(credits to Morphine-Milkshake){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.easier_time}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(2)
                    return true
                end
            }
        end
        if context.pre_discard  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(2)
                    return true
                end
            }
        end
        if context.ante_change  then
            if to_big((card.ability.extra.easier_time or 0)) == to_big(2) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Limit set to "..tostring(7), colour = G.C.BLUE})
                        
                        local current_hand_size = (G.hand.config.card_limit or 0)
                        local target_hand_size = 7
                        local difference = target_hand_size - current_hand_size
                        G.hand:change_size(difference)
                        return true
                    end
                }
            elseif to_big((card.ability.extra.easier_time or 0)) == to_big(4) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Limit set to "..tostring(7), colour = G.C.BLUE})
                        
                        local current_hand_size = (G.hand.config.card_limit or 0)
                        local target_hand_size = 7
                        local difference = target_hand_size - current_hand_size
                        G.hand:change_size(difference)
                        return true
                    end
                }
            elseif to_big((card.ability.extra.easier_time or 0)) == to_big(6) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Limit set to "..tostring(7), colour = G.C.BLUE})
                        
                        local current_hand_size = (G.hand.config.card_limit or 0)
                        local target_hand_size = 7
                        local difference = target_hand_size - current_hand_size
                        G.hand:change_size(difference)
                        return true
                    end
                }
            elseif to_big((card.ability.extra.easier_time or 0)) == to_big(8) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Limit set to "..tostring(7), colour = G.C.BLUE})
                        
                        local current_hand_size = (G.hand.config.card_limit or 0)
                        local target_hand_size = 7
                        local difference = target_hand_size - current_hand_size
                        G.hand:change_size(difference)
                        return true
                    end
                }
            else
                return {
                    func = function()
                        card.ability.extra.easier_time = (card.ability.extra.easier_time) + 1
                        return true
                    end
                }
            end
        end
    end
}