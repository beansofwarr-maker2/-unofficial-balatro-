
SMODS.Joker{ --Demented Joker
    key = "dementedjoker",
    config = {
        extra = {
            pasta_food = 50,
            repetitions = 1,
            chips0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Demented Joker',
        ['text'] = {
            [1] = 'd̴̩̤͂͒̂̉͜ọ̷̧̯̼̻̏̽͝f̸̛̛̦̼̦̫̔͑̌ ̵̧͓̹́̂ḩ̴̱̹̒͂͘y̸͇̻̫͋̌͘l̸̨̨̖̠̖̉͂̕͝ ̸̡͚̙̋̾͜f̶̜̩̝̺̅̆̉̚v̵̦͕̮̈́̐͆b̵̠̘̒̌̓̃ ̸̦̪̲͂͋ö̴̥̰͎͖̪l̸̬̺͒͐͝y̸̻̪̽̋̾ĺ̵̛̠̤̇,̷͚̫̙̯͚̾̋͘ ̵͓̟̥͍͗a̶̹͖̼͂̃̆̃ǫ̸͇̫̹̲̀̒̽̀ṕ̸̦̝̳̲̰̈́͗̂z̷̗̘̭͇͗ ̸͈͙̋̑p̵͓̉͐̇̽͠ẕ̸̈́̀͊̋͑ ̵͑̿͘ͅs̷̰̖̒̀͑̒̏v̵̜̼̊͜͜d̵̨͒͛̄ṙ̶̘͔͐ͅl̶̛̥̰̄̉́̔͜f̸̥͂͌͛̓̚ͅ ̴͎̻͚̣̀p̵͇̲̫̬̎̎̒̉̾t̴̢̛̬͎͙͖̓͛͠w̸̨̱̣̩͍̓ȳ̶̜̍͆̄̈ĺ̴̨͕̺̍͊z̸̧̡͋z̸̥̈́̑p̶̫̬̳̰͊c̷͎̊l̷̤̟̼̜̥̈͌̽̕',
            [2] = '{C:green}(credits to AYYLMAO2281337/Lord of the Dawn{}'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 5,
            y = 1
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 4,
        rarity = 1,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = true,
        atlas = 'CustomJokers',
        pools = { ["balatro_balatro_jokers"] = true },
        
        loc_vars = function(self, info_queue, card)
            
            return {vars = {card.ability.extra.pasta_food}}
        end,
        
        calculate = function(self, card, context)
            if context.cardarea == G.jokers and context.joker_main  then
                if true then
                    for i = 1, card.ability.extra.repetitions do
                        SMODS.calculate_effect({chips = 1}, card)
                    end
                else
                    card.ability.extra.pasta_food = math.max(0, (card.ability.extra.pasta_food) - 1)
                end
            end
        end
    }