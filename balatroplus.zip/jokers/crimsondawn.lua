
SMODS.Joker{ --Crimson Dawn
    key = "crimsondawn",
    config = {
        extra = {
            e2 = 40
        }
    },
    loc_txt = {
        ['name'] = 'Crimson Dawn',
        ['text'] = {
            [1] = '{C:blue}#1#+ chips{} for all played',
            [2] = 'cards, {C:attention}Decreases{} by 5',
            [3] = 'every {C:attention}Boss blind{} {C:inactive}[CHANGED]{}',
            [4] = '{C:green}(credits to Omicra98){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.e2}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                chips = card.ability.extra.e2
            }
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.e2 = math.max(0, (card.ability.extra.e2) - 5)
                    return true
                end
            }
        end
    end
}