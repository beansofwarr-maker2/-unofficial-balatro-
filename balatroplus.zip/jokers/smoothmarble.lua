
SMODS.Joker{ --Smooth Marble
    key = "smoothmarble",
    config = {
        extra = {
            odds = 4,
            mult0 = 5,
            chips0 = 40,
            xmult0 = 1.5,
            dollars0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Smooth Marble',
        ['text'] = {
            [1] = 'Each played {C:attention}Wild Card{}',
            [2] = 'has an equal chance to',
            [3] = 'give {C:red}+5 Mult{}, {C:blue}+40 Chips{},',
            [4] = '{X:red,C:white}1.5X{} {C:red}Mult{} or {C:money}1${}',
            [5] = '{C:green}(Credits to Morphine-Milkshake){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_balatro_smoothmarble')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_balatro_smoothmarble')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_balatro_smoothmarble')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_balatro_smoothmarble')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                if SMODS.pseudorandom_probability(card, 'group_0_e3b50f29', 1, card.ability.extra.odds, 'j_balatro_smoothmarble', false) then
                    SMODS.calculate_effect({mult = 5}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_865083bd', 1, card.ability.extra.odds, 'j_balatro_smoothmarble', false) then
                    SMODS.calculate_effect({chips = 40}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_2_722852a9', 1, card.ability.extra.odds, 'j_balatro_smoothmarble', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_3_3980a5db', 1, card.ability.extra.odds, 'j_balatro_smoothmarble', false) then
                    SMODS.calculate_effect({
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 1
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                            return true
                        end}, card)
                    end
                end
            end
        end
    }