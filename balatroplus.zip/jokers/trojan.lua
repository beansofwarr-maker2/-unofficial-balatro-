
SMODS.Joker{ --Trojan
    key = "trojan",
    config = {
        extra = {
            xmult0 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Trojan',
        ['text'] = {
            [1] = 'if played hand contains',
            [2] = 'a {C:attention}Wild Card{} and a {C:attention}Flush{},',
            [3] = '{C:hearts}DESTROY{} all played cards',
            [4] = 'and create a {C:tarot}Tarot Card{}',
            [5] = '{C:green}(Credits to Morphine-Milkshake){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balatro_balatro_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Flush" then
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'Tarot', })                            
                            card:juice_up(0.3, 0.5)
                            return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    Xmult = 0,
                    extra = {
                        message = created_consumable and localize('k_plus_tarot') or nil,
                        colour = G.C.PURPLE
                    }
                }
            end
        end
    end
}