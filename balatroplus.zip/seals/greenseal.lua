
SMODS.Seal {
    key = 'greenseal',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 4,
            xmult0 = 3
        }
    },
    badge_colour = HEX('32CD32'),
    loc_txt = {
        name = 'Green Seal',
        label = 'Green Seal',
        text = {
            [1] = '{C:green}1 in 4{} chance to give',
            [2] = '{X:red,C:white}X3{} Mult'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "coin7", per = 1.2, vol = 0.4 },
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_8a785c6d', 1, card.ability.seal.extra.odds, 'j_balatro_greenseal', false) then
                SMODS.calculate_effect({Xmult = 3}, card)
            end
        end
    end
}