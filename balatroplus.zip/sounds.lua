SMODS.Sound{
    key="JACKPOTTT",
    path="JACKPOTTT.ogg",
    pitch=0.7,
    volume=2,
}